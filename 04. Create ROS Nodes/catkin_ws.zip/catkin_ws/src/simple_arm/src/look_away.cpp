

// Include all of the necessary packages
#include "ros/ros.h"
#include "simple_arm/GoToPosition.h"
#include <sensor_msgs/JointState.h>        // For reading the arm joints’ positions
#include <sensor_msgs/Image.h>             // For using the camera data


// Define joints last position vector + moving state of the arm + the client that can request services
std::vector<double> joints_last_position{ 0, 0 };
bool moving_state = false;
ros::ServiceClient client;


// This function calls the safe_move service to safely move the arm to the center position
void move_arm_center() {

    ROS_INFO_STREAM("Moving the arm to the center");

    // Create a GoToPosition request message
    simple_arm::GoToPosition srv;

    // Move both joint angles to 1.57 radians
    srv.request.joint_1 = 1.57;
    srv.request.joint_2 = 1.57;

    // Call the safe_move service and pass the requested joint angles
    if (!client.call(srv))
        ROS_ERROR("Failed to call service safe_move");
}


// This callback function continuously executes and reads the arm joint angles position
void joint_states_callback(const sensor_msgs::JointState js) {

    // Get joints current position
    std::vector<double> joints_current_position = js.position;

    // Define a tolerance threshold to compare double values
    double tolerance = 0.0005;

    // If the current and previous joint states are the same (depending on tolerance). In this case, the arm stopped moving.
    if (fabs(joints_current_position[0] - joints_last_position[0]) < tolerance && fabs(joints_current_position[1] - joints_last_position[1]) < tolerance)

        // Set the moving_state flag to False
        moving_state = false;

    // If the current and previous joint states are different. In this case, the arm is moving.
    else {

        // Set the moving_state flag to true
        moving_state = true;

        // Update the joints_Last_position variable with current position data stored in joints_current_position
        joints_last_position = joints_current_position;
    }
}


// This callback function continuously executes and reads the image data
void look_away_callback(const sensor_msgs::Image img) {
    /*
     * This function receives image data from "/rgb_camera/image_raw" topic, and checks if all color values (in the image) are same as the color value
     * in the first pixel. If the image is uniform and the arm is not moving, the move_arm_center() function is called.
     */

    // Initialize uniform_image with true
    bool uniform_image = true;

    // Loop over the pixel indices in the image
    for (int i = 0; i < img.height * img.step; i++) {

        // If the current pixel is equal to the first pixel
        if (img.data[i] - img.data[0] != 0) {

            // Update the uniform_image to false
            uniform_image = false;

            // Break the loop
            break;
        }
    }

    // If the image is uniform and the arm is not moving, move the arm to the center
    if (uniform_image == true && moving_state == false)
        move_arm_center();
}


// Main function
int main(int argc, char** argv) {

    // Initialize the look_away node
    ros::init(argc, argv, "look_away");

    // Instantiate a NodeHandle object n to communicate with ROS
    ros::NodeHandle n;

    // Define a client service for requesting the services from safe_move
    client = n.serviceClient<simple_arm::GoToPosition>("/arm_mover/safe_move");

    // Create a subscriber object that subscribes to /simple_arm/joint_states topic (for tracking the arm position by reading the angle of each joint inside the joint_states_callback function)
    ros::Subscriber sub1 = n.subscribe("/simple_arm/joint_states", 10, joint_states_callback);

    // Create a subscriber object that subscribes to /rgb_camera/image_raw topic (for reading the image data inside the look_away_callback function)
    ros::Subscriber sub2 = n.subscribe("rgb_camera/image_raw", 10, look_away_callback);

    // Handle ROS communication events. This function blocks until a shutdown request is received by the node.
    ros::spin();

    return 0;
}