
// Include the necessary packages
#include "ros/ros.h"
#include "simple_arm/GoToPosition.h"       // This header file is generated from the GoToPosition.srv file
#include <std_msgs/Float64.h>


// Global joint publisher variables
ros::Publisher joint1_pub, joint2_pub;


// Function for checking and clamping the joint angles to a safe zone
std::vector<float> clamp_at_boundaries(float requested_j1, float requested_j2) {
    /*
     * This function is responsible for enforcing the minimum and maximum joint angles for each joint. So, if the joint angles passed
     * in are outside of the operable range, they will be “clamped” to the nearest allowable value. The minimum and maximum joint angles
     * are retrieved from the parameter server each time clamp_at_boundaries is called. The rest of this function simply clamps the joint
     * angle if necessary. Warning messages are logged if the requested joint angles are out of bounds.
     *
     * PARAMETERS
     * ============
     *      - requested_j1: Requested joint angle one
     *      - requested_j2: Requested joint angle two
     */

    // Define clamped joint angles and assign them to the requested ones
    float clamped_j1 = requested_j1;
    float clamped_j2 = requested_j2;

    // Declare the min and max joint parameters
    float min_j1, max_j1, min_j2, max_j2;

    // Create a new node handle (since we don't have access to the main node handle)
    ros::NodeHandle n2;

    // Get the node name
    std::string node_name = ros::this_node::getName();

    // Get the parameters for joints min and max
    n2.getParam(node_name + "/min_joint_1_angle", min_j1);
    n2.getParam(node_name + "/max_joint_1_angle", max_j1);
    n2.getParam(node_name + "/min_joint_2_angle", min_j2);
    n2.getParam(node_name + "/max_joint_2_angle", max_j2);

    // Check if joint 1 falls in the safe zone, otherwise clamp it
    if (requested_j1 < min_j1 || requested_j1 > max_j1) {
        clamped_j1 = std::min(std::max(requested_j1, min_j1), max_j1);
        ROS_WARN("j1 is out of bounds, valid range (%1.2f,%1.2f), clamping to: %1.2f", min_j1, max_j1, clamped_j1);
    }

    // Check if joint 2 falls in the safe zone, otherwise clamp it
    if (requested_j2 < min_j2 || requested_j2 > max_j2) {
        clamped_j2 = std::min(std::max(requested_j2, min_j2), max_j2);
        ROS_WARN("j2 is out of bounds, valid range (%1.2f,%1.2f), clamping to: %1.2f", min_j2, max_j2, clamped_j2);
    }

    // Keep the  clamped joint angles in a clamped_data vector
    std::vector<float> clamped_data = { clamped_j1, clamped_j2 };

    return clamped_data;
}


// Function for handling the safe_move service
bool handle_safe_move_request(simple_arm::GoToPosition::Request& req, simple_arm::GoToPosition::Response& res) {
    /*
     * When a client sends a GoToPosition request to the safe_move service, the handle_safe_move_request function is called.
     *
     * PARAMETERS
     * ===========
     *      - req: Short for request which has the type of GoToPosition::Request.
     *      - res: Short for response which has the type of GoToPosition::Response.
     */

    ROS_INFO("GoToPositionRequest received - j1:%1.2f, j2:%1.2f", (float)req.joint_1, (float)req.joint_2);

    // Check if requested joint angles are in the safe zone, otherwise clamp them
    std::vector<float> joints_angles = clamp_at_boundaries(req.joint_1, req.joint_2);

    // Publish clamped joint angles to the arm
    std_msgs::Float64 joint1_angle, joint2_angle;
    joint1_angle.data = joints_angles[0];
    joint2_angle.data = joints_angles[1];
    joint1_pub.publish(joint1_angle);
    joint2_pub.publish(joint2_angle);

    // Wait 3 seconds so the arm has enough time to move to the requested position
    ros::Duration(3).sleep();

    // Return a response message  indicating that the arm has moved to its new position and displays the clamped joint angles
    res.msg_feedback = "Joint angles set - j1: " + std::to_string(joints_angles[0]) + " , j2: " + std::to_string(joints_angles[1]);
    ROS_INFO_STREAM(res.msg_feedback);

    return true;
}


// Main function
int main(int argc, char** argv) {

    // Initialize the arm_mover node
    ros::init(argc, argv, "arm_mover");

    // Initialize the node handle n
    ros::NodeHandle n;

    // Create two publisher objects to publish joint angles to the arm
    joint1_pub = n.advertise<std_msgs::Float64>("/simple_arm/joint_1_position_controller/command", 10);
    joint2_pub = n.advertise<std_msgs::Float64>("/simple_arm/joint_2_position_controller/command", 10);

    // Create a safe_move service which calls the handle_safe_move_request function (this callback function runs when a service request is received)
    ros::ServiceServer service = n.advertiseService("/arm_mover/safe_move", handle_safe_move_request);
    ROS_INFO("Ready to send joint commands");

    // Handle ROS communication events. This function simply blocks until a shutdown request is received by the node.
    ros::spin();

    return 0;
}