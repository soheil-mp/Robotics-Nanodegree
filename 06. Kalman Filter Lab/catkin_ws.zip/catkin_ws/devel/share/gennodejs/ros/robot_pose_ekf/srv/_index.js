
"use strict";

let GetStatus = require('./GetStatus.js')

module.exports = {
  GetStatus: GetStatus,
};
